package com.example.quizquest;

public class ScoreBord {

    protected sining_up[] UsersNames;
}
